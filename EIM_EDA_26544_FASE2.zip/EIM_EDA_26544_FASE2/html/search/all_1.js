var searchData=
[
  ['bateria_0',['bateria',['../struct_meios.html#a6ff6a9fc4d44dc8de8b252254b486b54',1,'Meios']]]
];
