var searchData=
[
  ['inserircliente_0',['inserirCliente',['../_funcoes_8c.html#ad3387eb4c1197edd9ecd023aac0f02e7',1,'inserirCliente(Grafo x, int codCliente, char nome[], char localizacaoCliente[]):&#160;Funcoes.c'],['../_funcoes_8h.html#ad3387eb4c1197edd9ecd023aac0f02e7',1,'inserirCliente(Grafo x, int codCliente, char nome[], char localizacaoCliente[]):&#160;Funcoes.c']]],
  ['inserirmeio_1',['inserirMeio',['../_funcoes_8c.html#a9ef5f6186dedcf1815a07616bd2711e8',1,'inserirMeio(Grafo x, int codigoMeio, char tipoMeio[], char localizacao[], float bateria, float autonomia):&#160;Funcoes.c'],['../_funcoes_8h.html#a9ef5f6186dedcf1815a07616bd2711e8',1,'inserirMeio(Grafo x, int codigoMeio, char tipoMeio[], char localizacao[], float bateria, float autonomia):&#160;Funcoes.c']]]
];
