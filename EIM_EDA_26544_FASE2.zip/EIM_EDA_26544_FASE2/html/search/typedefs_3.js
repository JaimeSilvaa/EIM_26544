var searchData=
[
  ['meio_0',['Meio',['../_funcoes_8h.html#ab6faca6b8a9dbfb59313f2826557ffba',1,'Funcoes.h']]]
];
