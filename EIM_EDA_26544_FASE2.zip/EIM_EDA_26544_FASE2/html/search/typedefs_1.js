var searchData=
[
  ['cliente_0',['Cliente',['../_funcoes_8h.html#ade20127eae31988c46a6d8b8ec857243',1,'Funcoes.h']]]
];
