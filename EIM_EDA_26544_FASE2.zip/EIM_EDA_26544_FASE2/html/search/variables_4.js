var searchData=
[
  ['localizacao_0',['localizacao',['../struct_clientes.html#a0c841d830e50b0120ef0e414c2657d39',1,'Clientes::localizacao()'],['../struct_meios.html#a0c841d830e50b0120ef0e414c2657d39',1,'Meios::localizacao()']]]
];
