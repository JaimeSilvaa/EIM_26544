var searchData=
[
  ['grafo_0',['Grafo',['../_funcoes_8h.html#ad37b8e80b88e7c00572fb51601027bfa',1,'Funcoes.h']]],
  ['grafos_1',['Grafos',['../struct_grafos.html',1,'']]],
  ['guardarcliente_2',['guardarCliente',['../_funcoes_8c.html#a3072854753536c02adb91907e8513410',1,'guardarCliente(Grafo x):&#160;Funcoes.c'],['../_funcoes_8h.html#a3072854753536c02adb91907e8513410',1,'guardarCliente(Grafo x):&#160;Funcoes.c']]],
  ['guardargrafo_3',['guardarGrafo',['../_funcoes_8c.html#abdb519ab9272e49fe2ce147bec8c5468',1,'guardarGrafo(Grafo x):&#160;Funcoes.c'],['../_funcoes_8h.html#abdb519ab9272e49fe2ce147bec8c5468',1,'guardarGrafo(Grafo x):&#160;Funcoes.c']]],
  ['guardarmeio_4',['guardarMeio',['../_funcoes_8c.html#a62953128f8cf105c34f3108419145be6',1,'guardarMeio(Grafo x):&#160;Funcoes.c'],['../_funcoes_8h.html#a62953128f8cf105c34f3108419145be6',1,'guardarMeio(Grafo x):&#160;Funcoes.c']]]
];
