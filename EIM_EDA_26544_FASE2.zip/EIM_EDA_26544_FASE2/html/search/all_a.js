var searchData=
[
  ['nome_0',['nome',['../struct_clientes.html#ad9b32a94f9054fd81f59b1118b8d53d2',1,'Clientes']]]
];
