/*****************************************************************//**
 * \file   Funcoes.c
 * \brief  Ficheiro "Funcoes.c" usado para a cria��o das fun��es que permitem o funcionamento do programa.
 * 
 * \author Jaime Silva
 * \date   May 2023
 *********************************************************************/
#include "Funcoes.h"
#pragma region Meio

/**
 * \brief Fun��o que recebe um grafo e informa��es sobre um novo Meio de mobilidade.
*		  A fun��o procura um v�rtice com a localiza��o correspondente e insere o novo Meio como um n� adjacente a esse v�rtice.
*		  A fun��o retorna 1 se a inser��o foi bem-sucedida e 0 caso contr�rio.
 * 
 * \param x
 * \param codigoMeio
 * \param tipoMeio
 * \param localizacao
 * \param bateria
 * \param autonomia
 * \return 
 */
int inserirMeio(Grafo x,int codigoMeio, char tipoMeio[], char localizacao[], float bateria, float autonomia) {
	Meio novo;
	while ((x != NULL) && (strcmp(x->vertice, localizacao) != 0))
		x = x->seguinte;
	if (x == NULL)
		return(0);

	novo = malloc(sizeof(struct Meios));
	novo->codigoMeio = codigoMeio;
	strcpy(novo->tipoMeio, tipoMeio);
	strcpy(novo->localizacao, localizacao);
	novo->bateria = bateria;
	novo->autonomia = autonomia;
	novo->seguinte = x->meios;
	x->meios = novo;
	printf("Meio de mobilidade criado com sucesso\n");
	return(1);
}

/**
 * \brief Fun��o que guarda os Meios de mobilidade presentes num grafo de um arquivo de sa�da chamado "meios2.txt". 
 *		  Esta retorna 1 se a opera��o foi bem-sucedida, caso contr�rio, retorna 0.
 * 
 * \param x
 * \return 
 */
int guardarMeio(Grafo x) {
	FILE* fp;
	Meio aux;

	if (x == NULL)
		return(0);

	fp = fopen("meios2.txt", "w");
	if (fp == NULL)
		return(0);

	aux = x->meios;
	while (aux != NULL) {
		fprintf(fp, "%d;%s;%s;%0.2f;%0.2f;\n", aux->codigoMeio, aux->tipoMeio, aux->localizacao, aux->bateria, aux->autonomia);
		aux = aux->seguinte;
	}
	printf("Meios de mobilidade guardados com sucesso\n");
	fclose(fp);
	return(1);
}

/**
 * \brief Fun��o que guarda os Grafos presentes num grafo de um arquivo de sa�da chamado "grafo.txt". 
 *		  Esta retorna 1 se a opera��o foi bem-sucedida, caso contr�rio, retorna 0.
 * 
 * \param x
 * \return 
 */
int guardarGrafo(Grafo x) {
	Aresta aresta;
	FILE* fp;
	fp = fopen("grafo.txt", "w");
	if (fp != NULL) {
		while (x!=NULL)
		{
			aresta = x->arestas;

			while (aresta != NULL) {
				fprintf(fp, "%s;%0.2f;%s", x->vertice, aresta->distancia, aresta->seguinte->vertice);
				aresta = aresta->seguinte;
			}
			x = x->seguinte;
		}
		printf("Guardado com sucesso\n");
		fclose(fp);
		return(1);
	}
	return(0);
}


/*int lerMeio(Grafo x) {
	FILE* fp;
	int codigo;
	char tipoMeio[50], localizacao[50];
	float bateria, autonomia;
	fp = fopen("meios2.txt", "r");
	if (fp != NULL) {
		while (!feof(fp))
		{
			fscanf(fp, "%d;%[;];%[;];%0.2f;%0.2f\n", &codigo, &tipoMeio, &localizacao, &bateria, &autonomia);
			inserirMeio(x, codigo, tipoMeio, localizacao, bateria, autonomia);
		}
		fclose(fp);
		return(1);
	}
	return(0);
}*/

/*int lerGrafo(Grafo x, Grafo* y) {
	FILE* fp;
	char vertice[50], verticeAresta[50];
	float peso;
	fp = fopen("grafo.txt", "r");
	if (fp != NULL) {
		while (!feof(fp))
		{
			fscanf(fp, "%[;];%[;];%0.2f\n", vertice, verticeAresta, &peso);
			criarVertice(y, vertice);
			criarAresta(x, vertice, verticeAresta, peso);
		}
		fclose(fp);
		return(1);
	}
	return(0);
}*/

/**
 * \brief  Fun��o que lista todos os meios de mobilidade associados a uma determinada localiza��o de um Grafo x.
 * 
 * \param x
 * \param localizacao
 */
void listarMeio(Grafo x, char localizacao[]) {
	while ((x != NULL) && (strcmp(x->vertice, localizacao) != 0))
		x = x->seguinte;
	if (x != NULL)
	{
		Meio aux = x->meios;
		if (aux == NULL)printf("Nao tem meios de mobilidade\n");
		else while (aux != NULL) {
			printf("Codigo do meio de mobilidade: %d\n Tipo de meio de mobilidade: %s\n Bateria restante: %0.2f\n Autonomia para %0.2f km\n", aux->codigoMeio, aux->tipoMeio, aux->bateria, aux->autonomia);
			aux = aux->seguinte;
			printf("------------------------------------------------\n");
		}
	}
	else printf("localizacao inexistente\n");
}

/**
 * \brief Fun��o que aloca mem�ria para um novo v�rtice, define seu c�digo como cod e inicializa as suas listas de Meios de mobilidade e Clientes como NULL. 
 *		  Em seguida, define o novo v�rtice como o primeiro v�rtice do grafo e define a sua lista de arestas como NULL. 
 *		  Por fim, a fun��o retorna 1 se a cria��o do v�rtice foi bem-sucedida e 0 caso contr�rio.
 * 
 * \param x
 * \param cod
 * \return 
 */
int criarVertice(Grafo* x, char cod[]) {
	Grafo criarVertice = malloc(sizeof(struct Grafos));
	if (criarVertice != NULL) {
		strcpy(criarVertice->vertice, cod);
		criarVertice->meios = NULL;
		criarVertice->clientes = NULL;
		criarVertice->seguinte = *x;
		criarVertice->arestas = NULL;
		*x = criarVertice;
		printf("Vertice criado com sucesso\n");
		return(1);
	}
	else return(0);
}

/**
 * \brief Fun��o que recebe um grafo e um v�rtice como argumentos e retorna 1 se o v�rtice existir no grafo e 0 caso contr�rio. 
 *		  Ele percorre todos os v�rtices do grafo, comparando o nome do v�rtice atual com o nome do v�rtice de entrada at� encontrar um v�rtice com o mesmo nome ou at� o fim do grafo ser atingido. 
 *		  Se um v�rtice com o mesmo nome for encontrado, a fun��o retorna 1, caso contr�rio, retorna 0.
 * 
 * \param x
 * \param vertice
 * \return 
 */
int existeVertice(Grafo x, char vertice[]) {
	while (x != NULL) {
		if (strcmp(x->vertice, vertice) == 0)return(1);
		else
			x = x->seguinte;
	}
	return(0);
}

/**
 * \brief Fun��o que cria uma aresta entre dois v�rtices de um grafo. 
 *		  Ele recebe como par�metros o grafo em que ser� criada a aresta, o nome da origem e destino dos v�rtices que ser�o conectados, e a distancia da aresta.
 *		  Ele verifica se ambos os v�rtices j� existem no grafo, e se sim, percorre o grafo at� encontrar o v�rtice de origem e cria uma nova aresta apontando para o v�rtice de destino. 
 *		  Se a cria��o da aresta for bem sucedida, a fun��o retorna 1, caso contr�rio, retorna 0. 
 *		  Se um ou ambos os v�rtices n�o existem no grafo, a fun��o retorna -1.
 * 
 * \param x
 * \param origemV
 * \param destinoV
 * \param peso
 * \return 
 */
int criarAresta(Grafo x, char origemV[], char destinoV[], float distancia) {
	Aresta criarAresta;
	if (existeVertice(x, origemV) && existeVertice(x, destinoV)) {
		while (strcmp(x->vertice, origemV) != 0)
			x = x->seguinte;
		criarAresta = malloc(sizeof(struct Arestas));
		if (criarAresta != NULL) {
			strcpy(criarAresta->vertice, destinoV);
			criarAresta->distancia = distancia;
			criarAresta->seguinte = x->arestas;
			x->arestas = criarAresta;
			printf("Aresta criada com sucesso\n");
			return(1);
		}
		else {
			printf("Erro, nao foi possivel criar a aresta\n");
			return(0);
		}
	}
	else {
		printf("A localizacao de um ou ambos os vertices nao existem no grafo\n");
		return(-1);
	}
}

/**
 * \brief Fun��o que lista as arestas de um determinado v�rtice de um grafo. 
 *		  Esta recebe como par�metros um ponteiro para o grafo e o nome do v�rtice que se deseja listar as arestas.
 * 
 * \param x
 * \param vertice
 */
void listarArestas(Grafo x, char vertice[]) {
	Aresta aux;
	if (existeVertice(x, vertice)) {
		while (strcmp(x->vertice, vertice) != 0)
			x = x->seguinte;
		aux = x->arestas;
		while (aux != NULL)
		{
			printf("Aresta: %s\nDistancia: %.2f\n", aux->vertice, aux->distancia);
			aux = aux->seguinte;
			printf("------------------------------------------------\n");
		}
	}
	else printf("O vertice nao existe\n");
}
#pragma endregion

#pragma region Cliente
/**
 * \brief Fun��o que recebe um grafo e informa��es sobre um novo Cliente.
*		  A fun��o procura um v�rtice com a localiza��o correspondente e insere o novo Cliente como um n� adjacente a esse v�rtice.
*		  A fun��o retorna 1 se a inser��o foi bem-sucedida e 0 caso contr�rio.
 * 
 * \param x
 * \param codCliente
 * \param nome
 * \param localizacaoCliente
 * \return 
 */
int inserirCliente(Grafo x, int codCliente, char nome[], char localizacaoCliente[]) {
	while ((x != NULL) && (strcmp(x->vertice, localizacaoCliente) != 0))
		x = x->seguinte;
	if (x == NULL)return(0);
	else {
		Cliente criarCliente = malloc(sizeof(struct Clientes));
		strcpy(criarCliente->nome, nome);
		strcpy(criarCliente->localizacao, localizacaoCliente);
		criarCliente->codigoCliente = codCliente;
		criarCliente->seguinte = x->seguinte;
		x->clientes = criarCliente;
		printf("Cliente criado com sucesso\n");
		return(1);
	}
}

/**
 * \brief Fun��o que guarda os Clientes presentes num grafo de um arquivo de sa�da chamado "clientes2.txt". 
 *		  Esta retorna 1 se a opera��o foi bem-sucedida, caso contr�rio, retorna 0.
 * 
 * \param x
 * \return 
 */
int guardarCliente(Grafo x) {
	FILE* fp;
	fp = fopen("clientes2.txt", "w");
	if (fp != NULL) {
		Cliente aux = x->clientes;
		while (aux != NULL) {
			fprintf(fp, "%d;%s;%s\n", aux->codigoCliente, aux->nome, aux->localizacao);
			aux = aux->seguinte;
		}
		fclose(fp);
		printf("Clientes guardados com sucesso\n");
		return(1);
	}
	else return(0);
}

/**
 * \brief Fun��o que recebe um grafo e uma localiza��o de Cliente como argumentos.
 *		  Percorre o grafo at� encontrar a localiza��o do Cliente ou at� o fim do grafo.
 *		  Se a localiza��o for encontrada, lista os Clientes nessa localiza��o.
 *		  Caso contr�rio, imprime uma mensagem indicando que a localiza��o n�o existe.
 * 
 * \param x
 * \param localizacaoCliente
 */
void listarCliente(Grafo x, char localizacaoCliente[]) {
	while ((x != NULL) && (strcmp(x->vertice, localizacaoCliente) != 0))
		x = x->seguinte;
	if (x != NULL) {
		Cliente aux = x->clientes;
		if (aux == NULL)
			printf("Nao tem clientes na localizacao inserida\n");
		else while (aux != NULL) {
			printf("Codigo do Cliente: %d\n Nome do Cliente: %s", aux->codigoCliente, aux->nome);
			aux = aux->seguinte;
			printf("------------------------------------------------\n");
		}
	}
	else printf("Localizacao nao existe\n");
}

/**
 * \brief Fun��o que recebe um grafo, uma dist�ncia, uma localiza��o e um tipo de Meio de mobilidade como argumentos
 *		  e que lista os Meios de mobilidade que t�m uma autonomia menor ou igual � dist�ncia especificada e cujo tipo corresponde ao tipo de Meio de mobilidade especificado. 
 *		  Primeiro, ele procura o v�rtice especificado no grafo. 
 *		  Em seguida, para cada aresta conectada a esse v�rtice, ele verifica se a dist�ncia � menor ou igual � dist�ncia especificada e se o tipo de Meio de mobilidade corresponde ao tipo de Meio de mobilidade especificado. 
 *		  Se as condi��es forem atendidas, ele imprime as informa��es relevantes do Meio de mobilidade. 
 *		  Se nenhum Meio de mobilidade for encontrado, ele imprime uma mensagem informando que nenhum foi encontrado. 
 *		  Se a localiza��o especificada n�o estiver presente no grafo, ele imprime uma mensagem informando que o v�rtice indicado n�o existe.
 * 
 * \param x
 * \param distancia
 * \param localizacao
 * \param tipoMeio
 */
void listarDistancia(Grafo x, float distancia, char localizacao[], char tipoMeio[]) {
	Meio aux;
	Aresta aux2;
	Grafo vertice;
	int encontra = 0;
	if (existeVertice(x, localizacao)) {
		while (strcmp(x->vertice, localizacao) != 0) {
			x = x->seguinte;
		}
		vertice = x->vertice;
		aux = vertice->meios;
		aux2 = x->arestas;
		while (aux2 != NULL) {
			if (aux2->distancia <= distancia && strcmp(aux->tipoMeio, tipoMeio) == 0) {
				printf("Codigo do Meio de mobilidade:%d\n Tipo de Meio de mobilidade:%s\n Localizacao do Meio de mobilidade:%s\n Nivel de bateria:%0.2f\n Autonomia em km:%0.2f\n",
					aux->codigoMeio, aux->tipoMeio, aux->localizacao,aux->bateria,aux->autonomia);
				encontra = encontra + 1;
				aux2 = aux2->seguinte;
			}
			if (aux2 != NULL) {
				vertice = aux2->vertice;
				aux = vertice->meios;
			}
		}
		if (encontra == 0) {
			printf("Nao foi encontrado nenhum Meio de mobilidade num raio de %0.2f\n", distancia);
		}
	}
	else {
		printf("Vertice indicado nao existe\n");
	}
}
#pragma endregion