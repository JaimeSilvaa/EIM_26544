/*****************************************************************//**
 * \file   Funcoes.h
 * \brief  Ficheiro "Funcoes.h" onde s�o definidas as listas ligadas e � feita a ponte entre as fun��es e o main.
 * 
 * \author Jaime Silva
 * \date   May 2023
 *********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma warning (disable: 4996)

typedef struct Clientes {
	int codigoCliente;//c�digo do cliente
	char nome[50];//nome do cliente
	char localizacao[50];//localiza��o do cliente
	struct Clientes* seguinte;//endere�o de mem�ria para o pr�ximo cliente
}*Cliente;

typedef struct Meios {
	int codigoMeio;//c�digo do meio de mobilidade
	char tipoMeio[50];//tipo de meio de mobilidade
	char localizacao[50];//localiza��o do meio de mobilidade
	float bateria;//n�vel da bateria do meio de mobilidade
	float autonomia;//autonomia em km do meio de mobilidade
	struct Meios* seguinte;//endere�o de mem�ria para o proximo meio de mobilidade
}*Meio;

typedef struct Arestas {
	char vertice[50];//localiza��o
	float distancia;//dist�ncia de um meio de mobilidade ao outro
	struct Arestas* seguinte;//endere�o de mem�ria para a pr�xima aresta
}*Aresta;

typedef struct Grafos {
	char vertice[50];//localiza��o
	Aresta arestas;//lista ligada com os c�digos das arestas
	Meio meios;//lista ligada com os c�digos dos meios de mobilidade existentes neste geoc�digo
	Cliente clientes;//lista ligada com os c�digos dos clientes
	struct Grafos* seguinte;//endere�o de mem�ria para o pr�ximo grafo 
}*Grafo;

//Fun��es de Meios, Vertices, Arestas e Grafos
int inserirMeio(Grafo x, int codigoMeio, char tipoMeio[], char localizacao[], float bateria, float autonomia);
int guardarMeio(Grafo x);
int guardarGrafo(Grafo x);
//int lerMeio(Grafo x);
//int lerGrafo(Grafo x, Grafo* y);
void listarMeio(Grafo x, char localizacao[]);
int criarVertice(Grafo* x, char cod[]);
int existeVertice(Grafo x, char vertice[]);
int criarAresta(Grafo x, char origemV[], char destinoV[], float peso);
void listarArestas(Grafo x, char vertice[]);

//Fun��es de Clientes
int inserirCliente(Grafo x, int codCliente, char nome[], char localizacaoCliente[]);
int guardarCliente(Grafo x);
//int lerCliente(Grafo x);
void listarCliente(Grafo x, char localizacaoCliente[]);
void listarDistancia(Grafo x, float distancia, char localizacao[], char tipoMeio[]);