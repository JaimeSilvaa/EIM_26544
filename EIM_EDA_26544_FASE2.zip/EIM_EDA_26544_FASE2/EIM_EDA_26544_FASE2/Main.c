/*****************************************************************//**
 * \file   Main.c
 * \brief  Ficheiro "Main.c" que apresenta ao utilizador as funcionalidades do programa.
 * 
 * \author Jaime Silva
 * \date   May 2023
 *********************************************************************/

#include "Funcoes.h"

/**
 * \brief Menu apresentado ao utilizador.
 * 
 * \return 
 */
int menu() {
	int menu;
	printf("----------------------Menu----------------------\n");
	printf("1  - Inserir Meio de mobilidade\n");
	printf("2  - Inserir Cliente\n");
	printf("3  - Criar Vertice\n");
	printf("4  - Criar Aresta\n");
	printf("5  - Guardar Meios de mobilidade\n");
	printf("6  - Guardar Clientes\n");
	printf("7  - Guardar Grafos\n");
	printf("8  - Listar Arestas por localizacao\n");
	printf("9  - Listar Meios de mobilidade por localizacao\n");
	printf("10 - Listar Clientes por localizacao\n");
	printf("11 - Listar Meios de mobilidade numa area em torno do Cliente\n");
	printf("0  - Sair\n");
	printf("Opcao: \n");
	scanf("%d", &menu);
	printf("------------------------------------------------\n");
	return(menu);
}


int main() {
	//variavel para receber a opcao de escolha do menu
	int opcao;

	//variaveis para os grafos
	Grafo x = NULL;
	int caminho;

	//variaveis das listas e grafos
	int codigoCliente, codigoMeio, distancia, resposta;
	float bateria, autonomia, distanciaa;
	char nomeCliente[50], localizacaoCliente[50], tipoMeio[50], localizacaoMeio[50], verticeA[50], verticeB[50], localizacaoVertice[50];

	do {
		opcao = menu();
		switch (opcao)
		{
		case 1:printf("Codigo para novo Meio de mobilidade:\n");//op��o 1 para inserir um Meio de mobilidade
			   scanf("%d", &codigoMeio);
			   printf("Tipo de Meio de mobilidade:\n");
			   scanf("%s", tipoMeio);
			   printf("Localizacao do Meio de mobilidade:\n");
			   scanf("%s", localizacaoMeio);
			   printf("Bateria restante:\n");
			   scanf("%f", &bateria);
			   printf("Autonomia em km:\n");
			   scanf("%f", &autonomia);
			   resposta = inserirMeio(x, codigoMeio, tipoMeio, localizacaoMeio, bateria, autonomia);
			   printf("------------------------------------------------\n");
			   break;
		case 2:printf("Codigo do Cliente novo:\n");//op��o 2 para inserir um Cliente
			   scanf("%d", &codigoCliente);
			   printf("Nome do Cliente:\n");
			   scanf("%s", &nomeCliente);
			   printf("Localizacao do Cliente:\n");
			   scanf("%s", &localizacaoCliente);
			   resposta = inserirCliente(x, codigoCliente, nomeCliente, localizacaoCliente);
			   printf("------------------------------------------------\n");
			   break;
		case 3:printf("Localizacao do novo vertice:\n");//op��o 3 para criar um Vertice
			   scanf("%s", &localizacaoVertice);
			   resposta = criarVertice(&x, localizacaoVertice);
			   printf("------------------------------------------------\n");
			   break;
		case 4:printf("Localizacao do primeiro vertice da aresta:\n");//op��o 4 para criar uma Aresta
			   scanf("%s", &verticeA);
			   printf("Localizacao do segundo vertice da aresta:\n");
			   scanf("%s", &verticeB);
			   printf("Distancia da aresta:\n");
			   scanf("%f", &distanciaa);
			   resposta = criarAresta(x, verticeA, verticeB, distanciaa);
			   printf("------------------------------------------------\n");
			   break;
		case 5:resposta = guardarMeio(x);//op��o 5 para guardar os Meios de mobilidade
			   printf("------------------------------------------------\n");
			   break;
		case 6:resposta = guardarCliente(x);//op��o 6 para guardar os Clientes
			   printf("------------------------------------------------\n");
			   break;
		case 7:resposta = guardarGrafo(x);//op��o 7 para guardar os Grafos
			   printf("------------------------------------------------\n");
			   break;
		case 8:printf("Localizacao da aresta pretendida:\n");//op��o 8 para Listar as Arestas numa localiza��o espec�fica
			   scanf("%s", &localizacaoVertice);
			   printf("------------------------------------------------\n");
			   listarArestas(x, localizacaoVertice);
			   break;
		case 9:printf("Localizacao do Meio de mobilidade pretendido:\n");//op��o 9 para listar os Meios de mobilidade numa localiza��o espec�fica
			   scanf("%s", &localizacaoMeio);
			   printf("------------------------------------------------\n");
			   listarMeio(x, localizacaoMeio);
			   break;
		case 10:printf("Localizacao do Cliente pretendido:\n");//op��o 10 para listar os Clientes numa localiza��o espec�fica
				scanf("%s", &localizacaoCliente);
				printf("------------------------------------------------\n");
				listarCliente(x, localizacaoCliente);
				break;
		case 11:printf("Localizacao do Cliente:\n");//op��o 11 para listar os Meios de mobilidade numa determinada area em torno do Cliente
				scanf("%s", &localizacaoCliente);
				printf("Indique o raio em km:\n");
				scanf("%f", &distancia);
				printf("Tipo de Meio de mobilidade:\n");
				scanf("%s", &tipoMeio);
				printf("------------------------------------------------\n");
				listarDistancia(x, distancia, localizacaoCliente, tipoMeio);
				printf("------------------------------------------------\n");
				break;
		}
	} while (opcao != 0);
}