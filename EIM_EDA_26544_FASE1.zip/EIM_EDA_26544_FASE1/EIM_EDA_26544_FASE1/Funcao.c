/*****************************************************************//**
 * \file   Funcao.c
 * \brief  Ficheiro funcoes.c onde se encontram as funcoes do programa
 * 
 * \author Jaime Silva
 * \date   March 2023
 *********************************************************************/
#include "Funcoes.h"

//Funcoes relativas aos Meios de mobilidade
#pragma region Meio
/**
 * \brief Funcao para guardar os dados dos Meios de mobilidade para o ficheiro meios.txt.
 * 
 * \param inicioM
 * \return 
 */
int guardarMeio(Meio* inicio) {
    FILE* fp;
    fp = fopen("meios.txt", "w");

    if (fp != NULL) {
        Meio* aux = inicio;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%s;%0.2f;%0.2f;%s;%s\n", aux->codigoMeio, aux->tipoMeio,
                                   aux->bateriaMeio, aux->autonomiaMeio,
                                   aux->localizacaoMeio, aux->aluguerMeio);
            aux = aux->seguinte;
        }
        printf("Guardado com sucesso\n");
        fclose(fp);
        return(1);
    }
    else return(0);
}

/**
 * \brief Fun��o que l� os dados dos Meios de um ficheiro de texto chamado "meios.txt" e cria uma lista ligada desses Meios. 
 *        A fun��o abre o ficheiro para leitura e, em seguida, l� cada linha do ficheiro, que cont�m informa��es sobre Meios. 
 *        Em seguida, a fun��o chama a fun��o "inserirMeio" para inserir o Meio na lista ligada. 
 *        A fun��o retorna um ponteiro para o in�cio da lista ligada.
 * 
 * \return 
 */
Meio* lerMeio() {
    FILE* fp;
    int codigoM;
    float bateria, autonomia;
    char tipo[50], localizacao[50], aluguer[50];
    Meio* aux = NULL;
    fp = fopen("meios.txt", "r");
    if (fp != NULL)
    {
        while (!feof(fp))
        {
            fscanf(fp, "%d;%s;%0.2f;%0.2f;%s;%s\n", &codigoM, tipo, &bateria, &autonomia, localizacao, aluguer);
            aux = inserirMeio(aux, codigoM, tipo, bateria, autonomia, localizacao, aluguer);
        }
        fclose(fp);
    }
    return(aux);
}

/**
 * \brief Fun��o que insere um novo Meio numa lista ligada. 
 *        A fun��o verifica se j� existe um Meio com o mesmo c�digo e, se n�o houver, aloca mem�ria para um novo Meio e insere os dados fornecidos. 
 *        Em seguida, a fun��o atualiza o ponteiro de in�cio para apontar para o novo Meio e retorna o ponteiro atualizado. 
 *        Se j� houver um Meio com o mesmo c�digo, a fun��o retorna o ponteiro de in�cio original.
 * 
 * \param inicioM
 * \param codigoM
 * \param tipo
 * \param bateria
 * \param autonomia
 * \param localizacao
 * \param aluguer
 * \return 
 */
Meio* inserirMeio(Meio* inicio, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]) {
    if (!existeMeio(inicio, codigoM))
    {
        Meio* novoM = malloc(sizeof(struct registoMeio));
        if (novoM != NULL) {
            novoM->codigoMeio = codigoM;
            strcpy(novoM->tipoMeio, tipo);
            novoM->bateriaMeio = bateria;
            novoM->autonomiaMeio = autonomia;
            strcpy(novoM->localizacaoMeio, localizacao);
            strcpy(novoM->aluguerMeio, aluguer);
            novoM->seguinte = inicio;
            return(novoM);
        }
    }
    else return(inicio);
}

/**
 * \brief Fun��o que recebe um ponteiro para o in�cio da lista ligada dos Meios.
 *        Implementa o algoritmo de ordena��o bubble sort, ou seja, a cada passagem faz flutuar para o topo o maior elemento da sequ�ncia,
 *        em ordem decrescente na lista.
 *        Retorna um ponteiro para o novo in�cio da lista ap�s a ordena��o.
 * 
 * \param inicioM
 */
Meio* ordenarMeioDec(Meio* inicio) {
    int trocar = 1;
    Meio* atual;
    Meio* seguinte;
    Meio* anterior = NULL;

    if (inicio == NULL) {
        return NULL;
    }

    while (trocar) {
        trocar = 0;
        atual = inicio;
        seguinte = atual->seguinte;

        while (seguinte != NULL) {
            if (seguinte->autonomiaMeio > atual->autonomiaMeio) {
                if (anterior != NULL) {
                    anterior->seguinte = seguinte;
                }
                else {
                    inicio = seguinte;
                }
                atual->seguinte = seguinte->seguinte;
                seguinte->seguinte = atual;
                anterior = seguinte;
                seguinte = atual->seguinte;
                trocar = 1;
            }
            else {
                anterior = seguinte;
                atual = seguinte;
                seguinte = seguinte->seguinte;
            }
        }
    }
    return(inicio);
}

/**
 * \brief Fun��o que lista os Meios numa lista ligada. 
 *        A fun��o percorre a lista, imprimindo o c�digo, tipo, bateria, autonomia, localizacao e aluguer de cada Meio.
 * 
 * \param atualM
 */
void listarMeio(Meio* atual) {
    while (atual != NULL) {
        printf("%d;%s;%0.2f;%0.2f;%s;%s\n", atual->codigoMeio, atual->tipoMeio,
                                      atual->bateriaMeio, atual->autonomiaMeio,
                                      atual->localizacaoMeio, atual->aluguerMeio);
        atual = atual->seguinte;
    }
}
/**
 * \brief Funcao que verifica se um determinado Meio existe na lista, procurando por um c�digo espec�fico e retornando 1 caso exista e 0 caso contr�rio. 
 *        Ele percorre a lista usando um loop while e a cada itera��o verifica se o c�digo do Meio atual � igual ao c�digo procurado. 
 *        Se for encontrado um Meio com o c�digo procurado, a fun��o retorna 1 imediatamente. 
 *        Caso contr�rio, quando o loop termina, significa que n�o h� Meio com o c�digo procurado e a fun��o retorna 0.
 * 
 * \param inicioM
 * \param codigoM
 * \return 
 */
int existeMeio(Meio* inicio, int codigoM) {
    while (inicio != NULL)
    {
        if (inicio->codigoMeio == codigoM)return(1);
        inicio = inicio->seguinte;
    }
    return(0);
}

/**
 * \brief Funcao que recebe uma lista ligada de Meios e um c�digo de Meio a ser removido.
 *        Percorre a lista at� encontrar o Meio com o c�digo correspondente, removendo o Meio da lista.
 *        Retorna a nova cabe�a da lista se o Meio removido estava no in�cio da lista, ou a mesma cabe�a da lista recebida como par�metro caso contr�rio.
 * 
 * \param inicioM
 * \param codigoM
 * \return 
 */
Meio* removerMeio(Meio* inicio, int codigoM) {
    Meio* anterior = inicio, *atual = inicio, *aux;

    if (atual == NULL)return(NULL);
    else if (atual->codigoMeio == codigoM)//remover primeiro registo
    {
        aux = atual->seguinte;
        free(atual);
        return(aux);
    }
    else {
        while ((atual != NULL) && (atual->codigoMeio != codigoM))
        {
            anterior = atual;
            atual = atual->seguinte;
        }
        if (atual == NULL)return(inicio);
        else {
            anterior->seguinte = atual->seguinte;
            free(atual);
            return(inicio);
        }
    }
}

/**
 * \brief Fun��o que recebe como par�metros uma lista ligada de Meios de mobilidade e os dados para alterar um Meio espec�fico. 
 *        A fun��o percorre a lista de Meios at� encontrar o Meio com o c�digo especificado e altera os dados desse Meio de mobilidade. 
 *        A fun��o retorna a lista de Meios atualizada.
 * 
 * \param inicioM
 * \param codigoM
 * \param tipo
 * \param bateria
 * \param autonomia
 * \param localizacao
 * \param aluguer
 * \return 
 */
Meio* alterarMeio(Meio* inicio, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]) {
    Meio* atual = inicio;

    while (atual!=NULL)
    {
        if (atual->codigoMeio == codigoM) {//atualiza os dados do meio escolhido pelo codigo
            strcpy(atual->tipoMeio, tipo);
            atual->bateriaMeio = bateria;
            atual->autonomiaMeio = autonomia;
            strcpy(atual->localizacaoMeio, localizacao);
            strcpy(atual->aluguerMeio, aluguer);
            return(atual);
        }
        atual = atual->seguinte;
    }
    return(inicio);
}

/**
 * \brief Fun��o que recebe um ponteiro para o in�cio de uma lista ligada dos Meios e um c�digo de Meio a alugar.
*         Percorre a lista at� encontrar o Meio com o c�digo correspondente.
*         Se o Meio n�o estiver alugado, atualiza o campo "aluguerMeio" para "sim" e retorna 1.
*         Caso contr�rio, retorna 0 indicando que o Meio j� est� alugado.
*         Se o c�digo n�o for encontrado na lista, retorna -1.
 * 
 * \param inicioM
 * \param codigo
 * \return 
 */
int registoAluguerMeio(Meio* inicio, int codigo) {
    while (inicio != NULL) {
        if (inicio->codigoMeio == codigo) {
            if (stricmp(inicio->aluguerMeio, "sim") != 0) {
                strcpy(inicio->aluguerMeio, "sim");
                printf("Meio alugado com sucesso\n");
                return 1;
            }
            else {
                printf("Meio ja esta alugado\n");
                return 0;
            }
        }
        inicio = inicio->seguinte;
    }
    return -1;
}

/**
 * \brief  Fun��o que recebe um ponteiro para a cabe�a de uma lista ligada dos Meios, e exibe na tela o tipo de cada Meio e sua autonomia, 
 *         num formato espec�fico. 
 *         A fun��o percorre a lista de meios enquanto o ponteiro atual n�o � nulo, 
 *         exibindo na tela as informa��es do Meio atual e, em seguida, atualiza o ponteiro para apontar para o pr�ximo Meio na lista.
 * 
 * \param listar
 */
void listarMeioAutonomia(Meio* listar) {
    Meio* atual = listar;

    while (atual != NULL)
    {
            printf("%s, com %0.2f de autonomia\n", atual->tipoMeio, atual->autonomiaMeio);
            atual = atual->seguinte;
    }
}

/**
 * \brief Fun��o que recebe uma lista ligada de Meios e uma string que representa uma localiza��o. 
 *        A fun��o percorre a lista e imprime na tela os atributos de cada Meio da lista cuja localiza��o corresponde � string dada.
 * 
 * \param inicio
 * \param localizacao
 */
void listarMeioLocalizacao(Meio* inicio, char localizacao[]) {
    while (inicio != NULL)
    {
        if (strcmp(inicio->localizacaoMeio, localizacao) == 0) {
            printf("%d;%s;%0.2f;%0.2f;%s;%s\n", inicio->codigoMeio, inicio->tipoMeio, inicio->bateriaMeio,
                inicio->autonomiaMeio, inicio->localizacaoMeio, inicio->aluguerMeio);
        }
        inicio = inicio->seguinte;
    }
}

/**
 * \brief Fun��o que l� o arquivo "meios.txt"  e se o arquivo n�o for encontrado, a fun��o retorna. 
 *        Em seguida, um loop � executado para ler as informa��es do arquivo.
 *        As informa��es lidas s�o armazenadas em uma vari�vel da estrutura Meio e impressas na tela.
 *      
 * \param nomeArquivo
 */
void apenasListarMeio(char* nomeArquivo) {
    FILE* fp = fopen("meios.txt", "r");

    if (fp == NULL) {
        printf("Erro ao abrir o arquivo\n");
        return;
    }
    Meio meio;

    printf("Codigo  Tipo    Bateria    Autonomia    Localizacao    Alugado\n");
    printf("--------------------------------------------------------------\n");
    while (fscanf(fp, "%d;%[^;];%0.2f;%0.2f;%[^;];%[^;];", &meio.codigoMeio, meio.tipoMeio, &meio.bateriaMeio,&meio.autonomiaMeio,meio.localizacaoMeio,meio.aluguerMeio) == 6)
    {
        printf("%d %s %f %f %s %s\n", meio.codigoMeio,meio.tipoMeio,meio.bateriaMeio,meio.autonomiaMeio,meio.localizacaoMeio,meio.aluguerMeio);
    }
    fclose(fp);
}
#pragma endregion

//Funcoes relativas aos Clientes
#pragma region Cliente
/**
 * \brief Funcao para guardar os dados dos Clientes para o ficheiro clientes.txt.
 * 
 * \param inicioC
 * \return 
 */
int guardarCliente(Cliente* inicio) {
    FILE* fp;
    fp = fopen("clientes.txt", "w");
    if (fp != NULL) {
        Cliente* aux = inicio;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%d;%0.2f;%s;%s\n", aux->codigoCliente, aux->NIFCliente,
                               aux->saldoCliente, aux->nomeCliente, aux->mailCliente);
            aux = aux->seguinte;
        }
        printf("Guardado com sucesso\n");
        fclose(fp);
        return(1);
    }
    else return(0);
}

/**
 * \brief Fun��o que l� os dados dos Clientes de um ficheiro de texto chamado "clientes.txt" e cria uma lista ligada desses Clientes. 
 *        A fun��o abre o ficheiro para leitura e, em seguida, l� cada linha do ficheiro, que cont�m informa��es sobre Clientes. 
 *        Em seguida, a fun��o chama a fun��o "inserirCliente" para inserir o Cliente na lista ligada. 
 *        A fun��o retorna um ponteiro para o in�cio da lista ligada.
 * 
 * \return 
 */
Cliente* lerCliente() {
    FILE* fp;
    int codigoC, NIF;
    float saldo;
    char nomeC[50], mail[50];
    Cliente* aux = NULL;
    fp = fopen("clientes.txt", "r");
    if (fp != NULL)
    {
        while (!feof(fp))
        {
            fscanf(fp, "%d;%d;%0.2f;%s;%s\n", &codigoC, &NIF, &saldo, nomeC, mail);
            aux = inserirCliente(aux, codigoC, NIF, saldo, nomeC, mail);
        }
        fclose(fp);
    }
    return(aux);
}

/**
 * \brief Fun��o que insere um novo Cliente numa lista ligada. 
 *        A fun��o verifica se j� existe um Cliente com o mesmo c�digo e, se n�o houver, aloca mem�ria para um novo Cliente e insere os dados fornecidos. 
 *        Em seguida, a fun��o atualiza o ponteiro de in�cio para apontar para o novo Cliente e retorna o ponteiro atualizado. 
 *        Se j� houver um Cliente com o mesmo c�digo, a fun��o retorna o ponteiro de in�cio original.
 * 
 * \param inicioC
 * \param codigoC
 * \param NIF
 * \param saldo
 * \param nomeC
 * \param morada
 * \return 
 */
Cliente* inserirCliente(Cliente* inicio, int codigoC, int NIF, float saldo, char nomeC[], char mail[]) {
    if (!existeCliente(inicio, codigoC))
    {
        Cliente* novoC = malloc(sizeof(struct registoCliente));
        if (novoC != NULL) {
            novoC->codigoCliente = codigoC;
            novoC->NIFCliente = NIF;
            novoC->saldoCliente = saldo;
            strcpy(novoC->nomeCliente, nomeC);
            strcpy(novoC->mailCliente, mail);
            novoC->seguinte = inicio;
            return(novoC);
        }
    }
    else return(inicio);
}

/**
 * \brief Fun��o que verifica se um Cliente com o c�digo fornecido existe numa lista ligada.
 *        A fun��o percorre a lista procurando o Cliente com o c�digo fornecido e, quando o encontra, retorna 1. 
 *        Se o Cliente n�o for encontrado, a fun��o retorna 0.
 * 
 * \param inicioC
 * \param codigoC
 * \return 
 */
int existeCliente(Cliente* inicio, int codigoC) {
    while (inicio != NULL)
    {
        if (inicio->codigoCliente == codigoC)return(1);
        inicio = inicio->seguinte;
    }
    return(0);
}

/**
 * \brief Fun��o que lista os Clientes numa lista ligada. 
 *        A fun��o percorre a lista, imprimindo o c�digo, NIF, saldo, nome e mail de cada Cliente.
 * 
 * \param inicio
 */
void listarCliente(Cliente* inicio) {
    while (inicio != NULL)
    {
        printf("%d;%d;%0.2f;%s;%s\n", inicio->codigoCliente, inicio->NIFCliente,
            inicio->saldoCliente, inicio->nomeCliente, inicio->mailCliente);
        inicio = inicio->seguinte;
    }
}

/**
 * \brief Funcao para remover um Cliente ao selecionar o codigo respetivo. 
 *        Se o Cliente a ser removido � o primeiro na lista, o ponteiro de in�cio � atualizado para apontar para o pr�ximo Cliente.
 *        Se o Cliente n�o � encontrado, a fun��o retorna o ponteiro de in�cio original. 
 *        Caso contr�rio, o Cliente � removido e o ponteiro de in�cio original � retornado.
 * 
 * \param inicioC
 * \param codigoC
 * \return 
 */
Cliente* removerCliente(Cliente* inicio, int codigoC) {
    Cliente* anterior = inicio, *atual = inicio, *aux;

    if (atual == NULL)return(NULL);
    else if (atual->codigoCliente == codigoC)
    {
        aux = atual->seguinte;
        free(atual);
        return(aux);
    }
    else {
        while ((atual != NULL) && (atual->codigoCliente != codigoC))
        {
            anterior = atual;
            atual = atual->seguinte;
        }
        if (atual == NULL)return(inicio);
        else {
            anterior->seguinte = atual->seguinte;
            free(atual);
            return(inicio);
        }
    }
}

/**
 * \brief Fun��o que recebe uma lista ligada de Clientes, um c�digo de cliente, um NIF, um saldo, um nome e um e-mail. 
 *        A fun��o percorre a lista at� encontrar o Cliente correspondente ao c�digo passado e atualiza os seus dados com os valores passados nos par�metros. 
 *        Caso o Cliente n�o seja encontrado, a lista � retornada sem modifica��es.
 * 
 * \param inicioC
 * \param codigoC
 * \param nifC
 * \param saldoC
 * \param nomeC
 * \param moradaC
 * \return 
 */
Cliente* alterarCliente(Cliente* inicio, int codigoC, int nifC, float saldoC, char nomeC[], char mail[]) {
    Cliente* atual = inicio;

    while (atual != NULL)
    {
        if (atual->codigoCliente == codigoC) {//atualiza os dados do cliente escolhido pelo codigo
            atual->NIFCliente = nifC;
            atual->saldoCliente = saldoC;
            strcpy(atual->nomeCliente, nomeC);
            strcpy(atual->mailCliente, mail);
            return(atual);
        }
        atual = atual->seguinte;
    }
    return(inicio);
}

/**
 * \brief Fun��o que l� o arquivo "clientes.txt"  e se o arquivo n�o for encontrado, a fun��o retorna. 
 *        Em seguida, um loop � executado para ler as informa��es do arquivo.
 *        As informa��es lidas s�o armazenadas em uma vari�vel da estrutura Cliente e impressas na tela.
 * 
 * \param nomeArquivo
 */
void apenasListarCliente(char* nomeArquivo) {
    FILE* fp = fopen("clientes.txt", "r");

    if (fp == NULL) {
        printf("Erro ao abrir o arquivo\n");
        return;
    }
    Cliente cliente;

    printf("Codigo      NIF       Saldo     Nome     E-mail\n");
    printf("-----------------------------------------------\n");
    while (fscanf(fp, "%d;%d;%.2f;%[^;];%[^;]", &cliente.codigoCliente, &cliente.NIFCliente, &cliente.saldoCliente, cliente.nomeCliente, cliente.mailCliente) == 5)
    {
        printf("%d %d %f %s %s\n", cliente.codigoCliente, cliente.NIFCliente, cliente.saldoCliente, cliente.nomeCliente, cliente.mailCliente);
    }
    fclose(fp);
}
#pragma endregion

//Funcoes relativas aos Gestores
#pragma region Gestor
/**
 * \brief Funcao para guardar os dados dos Gestores para o ficheiro gestores.txt.
 * 
 * \param inicioG
 * \return 
 */
int guardarGestor(Gestor* inicio) {
    FILE* fp;
    fp = fopen("gestores.txt", "w");
    if (fp != NULL) {
        Gestor* aux = inicio;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%s;%d\n", aux->codigoGestor, aux->nomeGestor,aux->Pin);
            aux = aux->seguinte;
        }
        printf("Guardado com sucesso\n");
        fclose(fp);
        return(1);
    }
    else return(0);
}

/**
 * \brief Fun��o que l� os dados dos Gestores de um ficheiro de texto chamado "gestores.txt" e cria uma lista ligada desses Gestores. 
 *        A fun��o abre o ficheiro para leitura e, em seguida, l� cada linha do ficheiro, que cont�m informa��es sobre Gestores. 
 *        Em seguida, a fun��o chama a fun��o "inserirGestor" para inserir o Gestor na lista ligada. 
 *        A fun��o retorna um ponteiro para o in�cio da lista ligada.
 * 
 * \return 
 */
/*Gestor* lerGestor() {
    FILE* fp;
    int codigoG, PIN;
    char nomeG[50];
    Cliente* aux = NULL;
    fp = fopen("gestores.txt", "r");
    if (fp != NULL)
    {
        while (!feof(fp))
        {
            fscanf(fp, "%d;%s;%d\n", &codigoG, nomeG, &PIN);
            aux = inserirGestor(aux, codigoG, nomeG, PIN);
        }
        fclose(fp);
    }
    return(aux);
}*/

/**
 * \brief Fun��o que insere um novo Gestor numa lista ligada. 
 *        A fun��o verifica se j� existe um Gestor com o mesmo c�digo e, se n�o houver, aloca mem�ria para um novo Gestor e insere os dados fornecidos. 
 *        Em seguida, a fun��o atualiza o ponteiro de in�cio para apontar para o novo Gestor e retorna o ponteiro atualizado. 
 *        Se j� houver um Gestor com o mesmo c�digo, a fun��o retorna o ponteiro de in�cio original.
 * 
 * \param inicioG
 * \param codigoG
 * \param nomeG
 * \param PIN
 * \return 
 */
Gestor* inserirGestor(Gestor* inicio, int codigoG, char nomeG[], int PIN) {
    if (!existeGestor(inicio, codigoG))
    {
        Gestor* novoG = malloc(sizeof(struct registoGestor));
        if (novoG != NULL) {
            novoG->codigoGestor = codigoG;
            strcpy(novoG->nomeGestor, nomeG);
            novoG->Pin = PIN;
            novoG->seguinte = inicio;
            return(novoG);
        }
    }
    else return(inicio);
}

/**
 * \brief Fun��o que verifica se um Gestor com o c�digo fornecido existe numa lista ligada.
 *        A fun��o percorre a lista procurando o Gestor com o c�digo fornecido e, quando o encontra, retorna 1. 
 *        Se o Gestor n�o for encontrado, a fun��o retorna 0.
 * 
 * \param inicioG
 * \param codigoG
 * \return 
 */
int existeGestor(Gestor* inicio, int codigoG) {
    while (inicio != NULL)
    {
        if (inicio->codigoGestor == codigoG)return(1);
        inicio = inicio->seguinte;
    }
    return(0);
}

/**
 * \brief Fun��o que lista os Gestores numa lista ligada. 
 *        A fun��o percorre a lista, imprimindo o c�digo, nome e PIN de cada Gestor.
 * 
 * \param inicio
 */
/*void listarGestor(Gestor* inicio) {
    while (inicio != NULL)
    {
        printf("%d;%s;%d\n", inicio->codigoGestor, inicio->nomeGestor, inicio->Pin);
        inicio = inicio->seguinte;
    }
}*/

/**
 * \brief Funcao para remover um Gestor ao selecionar o codigo respetivo. 
 *        Se o Gestor a ser removido � o primeiro na lista, o ponteiro de in�cio � atualizado para apontar para o pr�ximo Gestor.
 *        Se o Gestor n�o � encontrado, a fun��o retorna o ponteiro de in�cio original. 
 *        Caso contr�rio, o Gestor � removido e o ponteiro de in�cio original � retornado.
 * 
 * \param inicioG
 * \param codigoG
 * \return 
 */
Gestor* removerGestor(Gestor* inicio, int codigoG) {
    Gestor* anterior = inicio, * atual = inicio, * aux;

    if (atual == NULL)return(NULL);
    else if (atual->codigoGestor == codigoG)
    {
        aux = atual->seguinte;
        free(atual);
        return(aux);
    }
    else {
        while ((atual != NULL) && (atual->codigoGestor != codigoG))
        {
            anterior = atual;
            atual = atual->seguinte;
        }
        if (atual == NULL)return(inicio);
        else {
            anterior->seguinte = atual->seguinte;
            free(atual);
            return(inicio);
        }
    }
}

/**
 * \brief A fun��o percorre a lista procurando o Gestor com o c�digo fornecido e, quando o encontra, atualiza o nome e o PIN e retorna o Gestor. 
 *        Se o Gestor n�o for encontrado, a fun��o retorna o ponteiro de in�cio original.
 * 
 * \param inicioG
 * \param codigoG
 * \param nomeG
 * \param pinG
 * \return 
 */
Gestor* alterarGestor(Gestor* inicio, int codigoG, char nomeG[], int pinG) {
    Gestor* atual = inicio;

    while (atual != NULL)
    {
        if (atual->codigoGestor == codigoG) {
            strcpy(atual->nomeGestor, nomeG);
            atual->Pin = pinG;
            return(atual);
        }
        atual = atual->seguinte;
    }
    return(inicio);
}

/**
 * \brief Fun��o que l� o arquivo "gestores.txt"  e se o arquivo n�o for encontrado, a fun��o retorna. 
 *        Em seguida, um loop � executado para ler as informa��es do arquivo.
 *        As informa��es lidas s�o armazenadas em uma vari�vel da estrutura Gestor e impressas na tela.
 * 
 * \param nomeArquivo
 */
void listarGestor(char* nomeArquivo) {
    FILE* fp = fopen("gestores.txt", "r");

    if (fp == NULL) {
        printf("Erro ao abrir o arquivo\n");
        return;
    }
    Gestor gestor;

    printf("Codigo      Nome    Pin\n");
    printf("-----------------------------\n");
    while (fscanf(fp, "%d;%[^;];%d",&gestor.codigoGestor,gestor.nomeGestor,&gestor.Pin)==3)
    {
        printf("%d %s %d\n", gestor.codigoGestor, gestor.nomeGestor, gestor.Pin);
    }
    fclose(fp);
}
#pragma endregion
