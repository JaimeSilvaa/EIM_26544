/*****************************************************************//**
 * \file   Funcao.c
 * \brief  Ficheiro funcoes.c onde se encontram as funcoes do programa
 * 
 * \author Jaime Silva
 * \date   March 2023
 *********************************************************************/
#include "Funcoes.h"

//Funcoes relativas aos Meios de mobilidade
#pragma region Meio
/**
 * \brief Funcao para guardar os dados dos Meios de mobilidade para o ficheiro meios.txt.
 * 
 * \param inicioM
 * \return 
 */
int guardarMeio(Meio* inicioM) {
    FILE* fp;
    fp = fopen("meios.txt", "w");
    if (fp != NULL) {
        Meio* aux = inicioM;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%s;%f;%f;%s;%s\n", aux->codigoMeio, aux->tipoMeio,
                                   aux->bateriaMeio, aux->autonomiaMeio,
                                   aux->localizacaoMeio, aux->aluguerMeio);
            aux = aux->seguinteM;
        }
        fclose(fp);
        return(1);
    }
    else return(0);
}

/**
 * \brief Funcao para ler os dados dos Meios de mobilidade do ficheiro meios.txt.
 * 
 * \return 
 */
Meio* lerMeio() {
    FILE* fp;
    int codigoM;
    float bateria, autonomia;
    char tipo[50];
    char localizacao[50];
    char aluguer[5];
    Meio* aux = NULL;
    fp = fopen("meios.txt", "r");
    if (fp != NULL)
    {
        while (!feof(fp))
        {
            fscanf(fp, "%d;%s;%f;%f;%s;%s\n", &codigoM, tipo, &bateria, &autonomia, localizacao, aluguer);
            aux = inserirMeio(aux, codigoM, tipo, bateria, autonomia, localizacao, aluguer);
        }
        fclose(fp);
    }
    return(aux);
}

/**
 * \brief Funcao para inserir um novo registo de Meio de mobilidade.
 * 
 * \param inicioM
 * \param codigoM
 * \param tipo
 * \param bateria
 * \param autonomia
 * \param localizacao
 * \param aluguer
 * \return 
 */
Meio* inserirMeio(Meio* inicioM, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]) {
    if (!existeMeio(inicioM, codigoM))
    {
        Meio* novoM = malloc(sizeof(struct registoMeio));
        if (novoM != NULL) {
            novoM->codigoMeio = codigoM;
            strcpy(novoM->tipoMeio, tipo);
            novoM->bateriaMeio = bateria;
            novoM->autonomiaMeio = autonomia;
            strcpy(novoM->localizacaoMeio, localizacao);
            strcpy(novoM->aluguerMeio, aluguer);
            novoM->seguinteM = inicioM;
            return(novoM);
        }
    }
    else return(inicioM);
}

/**
 * \brief Funcao para ordenar os Meios de mobilidade por ordem decrescente de autonomia.
 * 
 * \param inicioM
 */
void ordenarMeioDec(Meio* inicioM) {
    int aux = 1;
    Meio* atualM;
    Meio* proximoM;
    Meio* anteriorM = NULL;

    if (inicioM == NULL) {
        return NULL;
    }

    while (aux) {
        aux = 0;
        atualM = inicioM;
        proximoM = atualM->seguinteM;

        while (proximoM != NULL) {
            if (proximoM->autonomiaMeio > atualM->autonomiaMeio) {
                if (anteriorM != NULL) {
                    anteriorM->seguinteM = proximoM;
                }
                else {
                    inicioM = proximoM;
                }
                atualM->seguinteM = proximoM->seguinteM;
                proximoM->seguinteM = atualM;
                anteriorM = proximoM;
                proximoM = atualM->seguinteM;
                aux = 1;
            }
            else {
                anteriorM = atualM;
                atualM = proximoM;
                proximoM = proximoM->seguinteM;
            }
        }
    }
    return(inicioM);
}

/**
 * \brief Funcao para listar os dados dos Meios de mobilidade.
 * 
 * \param atualM
 */
void listarMeio(Meio* atualM) {
    while (atualM != NULL) {
        printf("%d;%s;%f;%f;%s;%s\n", atualM->codigoMeio, atualM->tipoMeio,
                                      atualM->bateriaMeio, atualM->autonomiaMeio,
                                      atualM->localizacaoMeio, atualM->aluguerMeio);
        atualM = atualM->seguinteM;
    }
}
/**
 * \brief Funcao para verificar se existe um determinado "codigo" em "inicioM".
 * 
 * \param inicioM
 * \param codigoM
 * \return 
 */
int existeMeio(Meio* inicioM, int codigoM) {
    while (inicioM != NULL)
    {
        if (inicioM->codigoMeio == codigoM)return(1);
        inicioM = inicioM->seguinteM;
    }
    return(0);
}

/**
 * \brief Funcao para remover um Meio de mobilidade ao selecionar o codigo respetivo.
 * 
 * \param inicioM
 * \param codigoM
 * \return 
 */
Meio* removerMeio(Meio* inicioM, int codigoM) {
    Meio* anteriorM = inicioM, * atualM = inicioM, * aux;

    if (atualM == NULL)return(NULL);
    else if (atualM->codigoMeio == codigoM)
    {
        aux = atualM->seguinteM;
        free(atualM);
        return(aux);
    }
    else {
        while ((atualM != NULL) && (atualM->codigoMeio != codigoM))
        {
            anteriorM = atualM;
            atualM = atualM->seguinteM;
        }
        if (atualM == NULL)return(inicioM);
        else {
            anteriorM->seguinteM = atualM->seguinteM;
            free(atualM);
            return(inicioM);
        }
    }
}

/**
 * \brief Funcao para alterar um meio de mobilidade escolhido atraves do seu codigo.
 * 
 * \param inicioM
 * \param codigoM
 * \param tipo
 * \param bateria
 * \param autonomia
 * \param localizacao
 * \param aluguer
 * \return 
 */
Meio* alterarMeio(Meio* inicioM, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]) {
    Meio* atualM = inicioM;

    while (atualM!=NULL)
    {
        if (atualM->codigoMeio == codigoM) {//atualiza os dados do meio escolhido pelo codigo
            strcpy(atualM->tipoMeio, tipo);
            atualM->bateriaMeio = bateria;
            atualM->autonomiaMeio = autonomia;
            strcpy(atualM->localizacaoMeio, localizacao);
            strcpy(atualM->aluguerMeio, aluguer);
            return(atualM);
        }
        atualM = atualM->seguinteM;
    }
    return(inicioM);
}

/**
 * \brief Funcao para listar os meios de mobilidade existentes numa localizacao com um respetivo geocodigo.
 * 
 * \param inicioM
 * \param local
 */
void listarMeioLocalizacao(Meio* inicioM, char local[]) {
    while (inicioM != NULL) {
        if (stricmp(inicioM->localizacaoMeio, local) == 0) {
            printf("%d;%s;%f;%f;%s;%s\n", inicioM->codigoMeio, inicioM->tipoMeio, inicioM->bateriaMeio,
                inicioM->autonomiaMeio, inicioM->localizacaoMeio, inicioM->aluguerMeio);
        }
        inicioM = inicioM->seguinteM;
    }
}

/**
 * \brief Funcao para verificar se um Meio de mobilidade esta alugado ao procurar pelo seu codigo.
 * 
 * \param inicioM
 * \param codigo
 * \return 
 */
int registoAluguerMeio(Meio* inicioM, int codigo) {
    while (inicioM != NULL) {
        if (inicioM->codigoMeio == codigo) {
            if (stricmp(inicioM->aluguerMeio, "alugado") != 0) {
                strcpy(inicioM->aluguerMeio, "alugado");
                return 1;
            }
            else return 0;
        }
        inicioM = inicioM->seguinteM;
    }
    return -1;
}
#pragma endregion

//Funcoes relativas aos Clientes
#pragma region Cliente
/**
 * \brief Funcao para guardar os dados dos Clientes para o ficheiro clientes.txt.
 * 
 * \param inicioC
 * \return 
 */
int guardarCliente(Cliente* inicioC) {
    FILE* fp;
    fp = fopen("clientes.txt", "w");
    if (fp != NULL) {
        Cliente* aux = inicioC;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%d;%f;%s;%s\n", aux->codigoCliente, aux->NIFCliente,
                               aux->saldoCliente, aux->nomeCliente, aux->morada);
            aux = aux->seguinteC;
        }
        fclose(fp);
        return(1);
    }
    else return(0);
}

/**
 * \brief Funcao para ler os dados dos Clientes do ficheiro clientes.txt.
 * 
 * \return 
 */
Cliente* lerCliente() {
    FILE* fp;
    int codigoC, NIF;
    float saldo;
    char nomeC[20];
    char morada[30];
    Cliente* aux = NULL;
    fp = fopen("clientes.txt", "r");
    if (fp != NULL)
    {
        while (!feof(fp))
        {
            fscanf(fp, "%d;%d;%f;%s;%s\n", &codigoC, &NIF, &saldo, nomeC, morada);
            aux = inserirCliente(aux, codigoC, NIF, saldo, nomeC, morada);
        }
        fclose(fp);
    }
    return(aux);
}

/**
 * \brief Funcao para inserir um novo registo de Cliente.
 * 
 * \param inicioC
 * \param codigoC
 * \param NIF
 * \param saldo
 * \param nomeC
 * \param morada
 * \return 
 */
Cliente* inserirCliente(Cliente* inicioC, int codigoC, int NIF, float saldo, char nomeC[], char morada[]) {
    if (!existeCliente(inicioC, codigoC))
    {
        Cliente* novoC = malloc(sizeof(struct registoCliente));
        if (novoC != NULL) {
            novoC->codigoCliente = codigoC;
            novoC->NIFCliente = NIF;
            novoC->saldoCliente = saldo;
            strcpy(novoC->nomeCliente, nomeC);
            strcpy(novoC->morada, morada);
            novoC->seguinteC = inicioC;
            return(novoC);
        }
    }
    else return(inicioC);
}

/**
 * \brief Funcao para verificar se existe um determinado "codigo" em "inicioC".
 * 
 * \param inicioC
 * \param codigoC
 * \return 
 */
int existeCliente(Cliente* inicioC, int codigoC) {
    while (inicioC != NULL)
    {
        if (inicioC->codigoCliente == codigoC)return(1);
        inicioC = inicioC->seguinteC;
    }
    return(0);
}

/**
 * \brief Funcao para remover um Cliente ao selecionar o codigo respetivo.
 * 
 * \param inicioC
 * \param codigoC
 * \return 
 */
Cliente* removerCliente(Cliente* inicioC, int codigoC) {
    Cliente* anteriorC = inicioC, * atualC = inicioC, * aux;

    if (atualC == NULL)return(NULL);
    else if (atualC->codigoCliente == codigoC)
    {
        aux = atualC->seguinteC;
        free(atualC);
        return(aux);
    }
    else {
        while ((atualC != NULL) && (atualC->codigoCliente != codigoC))
        {
            anteriorC = atualC;
            atualC = atualC->seguinteC;
        }
        if (atualC == NULL)return(inicioC);
        else {
            anteriorC->seguinteC = atualC->seguinteC;
            free(atualC);
            return(inicioC);
        }
    }
}

/**
 * \brief Funcao para alterar os dados de um Cliente ao procurar o respetivo codigo.
 * 
 * \param inicioC
 * \param codigoC
 * \param nifC
 * \param saldoC
 * \param nomeC
 * \param moradaC
 * \return 
 */
Cliente* alterarCliente(Cliente* inicioC, int codigoC, int nifC, float saldoC, char nomeC[], char moradaC[]) {
    Cliente* atualC = inicioC;

    while (atualC != NULL)
    {
        if (atualC->codigoCliente == codigoC) {//atualiza os dados do cliente escolhido pelo codigo
            atualC->NIFCliente = nifC;
            atualC->saldoCliente = saldoC;
            strcpy(atualC->nomeCliente, nomeC);
            strcpy(atualC->morada, moradaC);
            return(atualC);
        }
        atualC = atualC->seguinteC;
    }
    return(inicioC);
}
#pragma endregion

//Funcoes relativas aos Gestores
#pragma region Gestor
/**
 * \brief Funcao para guardar os dados dos Gestores para o ficheiro gestores.txt.
 * 
 * \param inicioG
 * \return 
 */
int guardarGestor(Gestor* inicioG) {
    FILE* fp;
    fp = fopen("gestores.txt", "w");
    if (fp != NULL) {
        Gestor* aux = inicioG;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%s;%d\n", aux->codigoGestor, aux->nomeGestor,aux->Pin);
            aux = aux->seguinteG;
        }
        fclose(fp);
        return(1);
    }
    else return(0);
}

/**
 * \brief Funcao para ler os dados dos Gestores do ficheiro gestores.txt.
 * 
 * \return 
 */
Gestor* lerGestor() {
    FILE* fp;
    int codigoG, PIN;
    char nomeG[20];
    Cliente* aux = NULL;
    fp = fopen("gestores.txt", "r");
    if (fp != NULL)
    {
        while (!feof(fp))
        {
            fscanf(fp, "%d;%s;%d\n", &codigoG, nomeG, &PIN);
            aux = inserirGestor(aux, codigoG, nomeG, PIN);
        }
        fclose(fp);
    }
    return(aux);
}

/**
 * \brief Funcao para inserir um novo registo de Gestor.
 * 
 * \param inicioG
 * \param codigoG
 * \param nomeG
 * \param PIN
 * \return 
 */
Gestor* inserirGestor(Gestor* inicioG, int codigoG, char nomeG[], int PIN) {
    if (!existeGestor(inicioG, codigoG))
    {
        Gestor* novoG = malloc(sizeof(struct registoGestor));
        if (novoG != NULL) {
            novoG->codigoGestor = codigoG;
            strcpy(novoG->nomeGestor, nomeG);
            novoG->Pin = PIN;
            novoG->seguinteG = inicioG;
            return(novoG);
        }
    }
    else return(inicioG);
}

/**
 * \brief Funcao para verificar se existe um determinado "codigo" em "inicioG".
 * 
 * \param inicioG
 * \param codigoG
 * \return 
 */
int existeGestor(Gestor* inicioG, int codigoG) {
    while (inicioG != NULL)
    {
        if (inicioG->codigoGestor == codigoG)return(1);
        inicioG = inicioG->seguinteG;
    }
    return(0);
}

/**
 * \brief Funcao para remover um Gestor ao selecionar o codigo respetivo.
 * 
 * \param inicioG
 * \param codigoG
 * \return 
 */
Gestor* removerGestor(Gestor* inicioG, int codigoG) {
    Gestor* anteriorG = inicioG, * atualG = inicioG, * aux;

    if (atualG == NULL)return(NULL);
    else if (atualG->codigoGestor == codigoG)
    {
        aux = atualG->seguinteG;
        free(atualG);
        return(aux);
    }
    else {
        while ((atualG != NULL) && (atualG->codigoGestor != codigoG))
        {
            anteriorG = atualG;
            atualG = atualG->seguinteG;
        }
        if (atualG == NULL)return(inicioG);
        else {
            anteriorG->seguinteG = atualG->seguinteG;
            free(atualG);
            return(inicioG);
        }
    }
}

/**
 * \brief Funcao para alterar os dados de um Gestor ao procurar o respetivo codigo.
 * 
 * \param inicioG
 * \param codigoG
 * \param nomeG
 * \param pinG
 * \return 
 */
Gestor* alterarGestor(Gestor* inicioG, int codigoG, char nomeG[], int pinG) {
    Gestor* atualG = inicioG;

    while (atualG != NULL)
    {
        if (atualG->codigoGestor == codigoG) {//atualiza os dados do gestor escolhido pelo codigo
            strcpy(atualG->nomeGestor, nomeG);
            atualG->Pin = pinG;
            return(atualG);
        }
        atualG = atualG->seguinteG;
    }
    return(inicioG);
}
#pragma endregion
