/*****************************************************************//**
 * \file   Main.c
 * \brief  Ficheiro main.c onde o programa inicializa e interage com o utilizador
 * 
 * \author Jaime Silva
 * \date   March 2023
 *********************************************************************/
#include "Funcoes.h"

/**
 * \brief menu apresentado ao utilizador ao iniciar a aplicacao.
 * 
 * \return 
 */
int menu() {
    int ini;
    printf("---------------MENU PRINCIPAL---------------\n");
    printf("1 - Menu Cliente\n");
    printf("2 - Menu Gestor\n");
    printf("0 - Sair\n");
    printf("Opcao:\n");
    scanf("%d", &ini);
    printf("--------------------------------------------\n");
    return(ini);
}

//Menu Cliente apresentado ao utilizador
int menuCliente() {
    int Cli;
    printf("---------------MENU CLIENTE---------------\n");
    printf("1 - Guardar Clientes\n");
    printf("2 - Inserir um Cliente\n");
    printf("3 - Alugar Meio de mobilidade\n");
    printf("4 - Listar os Clientes\n");
    printf("5 - Listar Meios de mobilidade por ordem decrescente de autonomia\n");
    printf("6 - Listar Meios de mobilidade por localizacao\n");
    printf("0 - Voltar ao Menu inicial\n");
    printf("Opcao:\n");
    scanf("%d", &Cli);
    printf("------------------------------------------\n");
    return(Cli);
}

//Menu Gestor apresentado ao utilizador
int menuGestor() {
    int Ges;
    printf("---------------MENU GESTOR---------------\n");
    printf(" 1 - Inserir um Gestor\n");
    printf(" 2 - Remover um Gestor\n");
    printf(" 3 - Guardar os Gestores\n");
    printf(" 4 - Listar os Gestores\n");
    printf(" 5 - Alterar um Gestor\n");
    printf(" 6 - Inserir um Cliente\n");
    printf(" 7 - Remover um Cliente\n");
    printf(" 8 - Guardar os Clientes\n");
    printf(" 9 - Listar os Clientes\n");
    printf("10 - Alterar um Cliente\n");
    printf("11 - Inserir um Meio de mobilidade\n");
    printf("12 - Remover um Meio de mobilidade\n");
    printf("13 - Guardar os Meios de mobilidade\n");
    printf("14 - Listar os Meios de mobilidade\n");
    printf("15 - Alterar um Meio de mobilidade\n");
    printf("16 - Alugar Meio de mobilidade\n");
    printf("17 - Listar Meios de mobilidade a partir da localizacao\n");
    printf("18 - Listar Meios de mobilidade por ordem decrescente de autonomia\n");
    printf("0 - Voltar ao Menu inicial\n");
    printf("Opcao:\n");
    scanf("%d", &Ges);
    printf("-----------------------------------------\n");
    return(Ges);
}

/**
 * \brief .
 * 
 * \return 
 */
int mCliente() {
    int Cli;

    //variaveis para struct Meio
    int codigoM;
    char tipoM[50], localizacaoM[50], aluguerM[50];
    float bateriaM, autonomiaM;

    //variaveis para struct Cliente
    int codigoC, nifC;
    char nomeC[50], mailC[50];
    float saldoC;

    //listas ligadas vazias
    Meio* meio = NULL;
    Cliente* cliente = NULL;

    do {
        Cli = menuCliente();
        switch (Cli)
        {
        case 1: guardarCliente(cliente);
                break;
        case 2:printf("Codigo?\n");
               scanf("%d", &codigoC);
               printf("NIF?\n");
               scanf("%d", &nifC);
               printf("Saldo?\n");
               scanf("%f", &saldoC);
               printf("Nome?\n");
               scanf("%s", &nomeC);
               printf("E-mail?\n");
               scanf("%s", &mailC);
               cliente = inserirCliente(cliente, codigoC, nifC, saldoC, nomeC, mailC);
               guardarCliente(cliente);;
                break;
        case 3:printf("Codigo do Meio de mobilidade pretendido?\n");
               scanf("%d", &codigoM);
               registoAluguerMeio(meio, codigoM);
                break;
        case 4://cliente = lerCliente();
               //listarCliente(cliente);
                break;
        case 5:ordenarMeioDec(meio);
               listarMeio(meio);
                break;
        case 6:printf("Qual a localizacao do meio de mobilidade:\n");
               scanf("%s", &localizacaoM);
               listarMeioLocalizacao(meio, localizacaoM);
                break;
        }
    } while (Cli != 0);
}

//Menu Gestor
int mGestor() {
    int Ges;

    //variaveis para struct Meio
    int codigoM;
    char tipoM[50], localizacaoM[50], aluguerM[50];
    float bateriaM, autonomiaM;

    //variaveis para struct Cliente
    int codigoC, nifC;
    char nomeC[50], mailC[50];
    float saldoC;

    //variaveis para Gestor
    int codigoG, pinG;
    char nomeG[20];

    //listas ligadas vazias
    Meio* meio = NULL;
    Cliente* cliente = NULL;
    Gestor* gestor = NULL;

    do {
        Ges = menuGestor();
        switch (Ges)
        {
        case 1: printf("Codigo do Gestor?\n");
                scanf("%d", &codigoG);
                printf("Nome?\n");
                scanf("%s", &nomeG);
                printf("Pin de seguranca?\n");
                scanf("%d", &pinG);
                gestor = inserirGestor(gestor, codigoG, nomeG, pinG);
                break;
        case 2: printf("Codigo do Gestor a remover?\n");
                scanf("%d", &codigoG);
                gestor = removerGestor(gestor, codigoG);
                break;
        case 3: guardarGestor(gestor);
                break;
        case 4: //gestor = lerGestor();
                //listarGestor(gestor);
                listarGestor("gestores.txt");
                break;
        case 5: printf("Codigo do Gestor a ser alterado?\n");
                scanf("%d", &codigoG);
                printf("Nome do Gestor?\n");
                scanf("%s", &nomeG);
                printf("Pin de seguran�a?\n");
                scanf("%d", &pinG);
                gestor = alterarGestor(gestor, codigoG, nomeG, pinG);
                break;
        case 6: printf("Codigo do Cliente?\n");
                scanf("%d", &codigoC);
                printf("NIF?\n");
                scanf("%d", &nifC);
                printf("Saldo?\n");
                scanf("%f", &saldoC);
                printf("Nome?\n");
                scanf("%s", &nomeC);
                printf("E-mail?\n");
                scanf("%s", &mailC);
                cliente = inserirCliente(cliente, codigoC, nifC, saldoC, nomeC, mailC);
                break;
        case 7: printf("Codigo do Cliente a remover?\n");
                scanf("%d", &codigoC);
                cliente = removerCliente(cliente, codigoC);
                break;
        case 8: guardarCliente(cliente);
                break;
        case 9: //cliente = lerCliente();
                //listarCliente(cliente);
                apenasListarCliente("clientes.txt");
                break;
        case 10: printf("Codigo do Cliente a ser alterado?\n");
                 scanf("%d", &codigoC);
                 printf("NIF do Cliente?\n");
                 scanf("%d", &nifC);
                 printf("Saldo do Cliente?\n");
                 scanf("%f", &saldoC);
                 printf("Nome do Cliente?\n");
                 scanf("%s", &nomeC);
                 printf("E-mail do Cliente?\n");
                 scanf("%s", &mailC);
                 cliente = alterarCliente(cliente, codigoC, nifC, saldoC, nomeC, mailC);
                 break;
        case 11: printf("Codigo do Meio de mobilidade?\n");
                 scanf("%d", &codigoM);
                 printf("Tipo do Meio de mobilidade?\n");
                 scanf("%s", &tipoM);
                 printf("Percentagem da bateria?\n");
                 scanf("%f", &bateriaM);
                 printf("Autonomia?\n");
                 scanf("%f", &autonomiaM);
                 printf("Localizacao?\n");
                 scanf("%s", &localizacaoM);
                 printf("Alugada?\n");
                 scanf("%s", &aluguerM);
                 meio = inserirMeio(meio, codigoM, tipoM, bateriaM, autonomiaM, localizacaoM, aluguerM);
                 break;
        case 12: printf("Codigo do Meio de mobilidade a remover?\n");
                 scanf("%d", &codigoM);
                 meio = removerMeio(meio, codigoM);
                 break;
        case 13: guardarMeio(meio);
                 break;
        case 14: //meio = lerMeio();
                 //listarMeio(meio);
                 apenasListarMeio("meios.txt");
                 break;
        case 15: printf("Codigo do Meio de mobilidade a ser alterado?\n");
                 scanf("%d", &codigoM);
                 printf("Tipo do Meio de mobilidade?\n");
                 scanf("%s", &tipoM);
                 printf("Percentagem da bateria?\n");
                 scanf("%f", &bateriaM);
                 printf("Autonomia?\n");
                 scanf("%f", &autonomiaM);
                 printf("Localizacao?\n");
                 scanf("%s", &localizacaoM);
                 printf("Alugada?\n");
                 scanf("%s", &aluguerM);
                 meio = alterarMeio(meio,codigoM,tipoM,bateriaM,autonomiaM,localizacaoM,aluguerM);
                 break;
        case 16: printf("Codigo do Meio de mobilidade pretendido?\n");
                 scanf("%d", &codigoM);
                 registoAluguerMeio(meio, codigoM);
                 break;
        case 17: printf("Localizacao para procurar Meios de mobilidade?\n");
                 scanf("%s", &localizacaoM);
                 listarMeioLocalizacao(meio, localizacaoM);
                 break;
        case 18: ordenarMeioDec(meio);
                 listarMeio(meio);
                 break;
        }
    }while (Ges != 0);
}

//Menu inicial
int main() {
    int ini;
    Meio* meio = NULL; //lista ligada vazia dos meios de mobilidade
    Cliente* cliente = NULL; //lista ligada vazia dos clientes
    Gestor* gestor = NULL; //lista ligada vazia dos gestores
    do {
        ini = menu();
        switch (ini)
        {
        case 1:mCliente();
            break;
        case 2:mGestor();
            break;
        }
    }while (ini != 0);
    return(0);
}