/*****************************************************************//**
 * \file   Main.c
 * \brief  Ficheiro main.c onde o programa inicializa e interage com o utilizador
 * 
 * \author Jaime Silva
 * \date   March 2023
 *********************************************************************/
#include "Funcoes.h"

//Menu apresentado ao utilizador ao inicializar a aplicacao
int menu() {
    int ini;
    printf("---------------MENU---------------\n");
    printf("1 - Menu Cliente\n");
    printf("2 - Menu Gestor\n");
    printf("0 - Sair\n");
    printf("Opcao:\n");
    scanf("%d", &ini);
    return(ini);
}

//Menu Cliente apresentado ao utilizador
int menuCliente() {
    int Cli;
    printf("---------------MENU CLIENTE---------------\n");
    printf("1 - Inserir um Cliente\n");
    printf("2 - Listar os Meios de mobilidade\n");
    printf("3 - Listar Meios de mobilidade por ordem decrescente de autonomia\n");
    printf("4 - Voltar ao Menu inicial\n");
    printf("0 - Sair\n");
    printf("Opcao:\n");
    scanf("%d", &Cli);
    return(Cli);
}

//Menu Gestor apresentado ao utilizador
int menuGestor() {
    int Ges;
    printf("---------------MENU GESTOR---------------\n");
    printf("1 - Inserir um Gestor\n");
    printf("2 - Remover um Gestor\n");
    printf("3 - Guardar os Gestores\n");
    printf("4 - Ler Gestores\n");
    printf("5 - Alterar um Gestor\n");
    printf("6 - Inserir um Cliente\n");
    printf("7 - Remover um Cliente\n");
    printf("8 - Guardar os Clientes\n");
    printf("9 - Ler Clientes\n");
    printf("10 - Alterar um Cliente\n");
    printf("11 - Inserir um Meio de mobilidade\n");
    printf("12 - Remover um Meio de mobilidade\n");
    printf("13 - Guardar os Meios de mobilidade\n");
    printf("14 - Ler Meios de mobilidade\n");
    printf("15 - Listar os Meios de mobilidade\n");
    printf("16 - Alterar um Meio de mobilidade\n");
    printf("17 - Registo de aluguer Meio de mobilidade\n");
    printf("18 - Listar Meios de mobilidade num geocodigo\n");
    printf("19 - Listar Meios de mobilidade por ordem decrescente de autonomia\n");
    printf("20 - Voltar ao Menu inicial\n");
    printf("0 - Sair\n");
    printf("Opcao:\n");
    scanf("%d", &Ges);
    return(Ges);
}

//Menu Cliente
int mCliente() {
    int Cli;
    Meio* meio = NULL; //lista ligada vazia dos meios de mobilidade
    Cliente* cliente = NULL; //lista ligada vazia dos clientes
    int codigoM, codigoC, nifC;
    char tipoM[50], localizacaoM[50], aluguerM[10], nomeC[20], moradaC[30];
    float bateriaM, autonomiaM, saldoC;

    do {
        Cli = menuCliente();
        switch (Cli)
        {
        case 1: printf("Codigo?\n");
                scanf("%d", &codigoC);
                printf("NIF?\n");
                scanf("%d", &nifC);
                printf("Saldo?\n");
                scanf("%f", &saldoC);
                printf("Nome?\n");
                scanf("%s", &nomeC);
                printf("Morada?\n");
                scanf("%s", &moradaC);
                cliente = inserirCliente(cliente, codigoC, nifC, saldoC, nomeC, moradaC);
                guardarCliente(cliente);
                break;
        case 2:listarMeio(meio);
                break;
        case 3:ordenarMeioDec(meio);
                break;
        case 4:main();
                break;
        }
    } while (Cli != 0);
    return(0);
}

//Menu Gestor
int mGestor() {
    int Ges;
    Meio* meio = NULL; //lista ligada vazia dos meios de mobilidade
    Cliente* cliente = NULL; //lista ligada vazia dos clientes
    Gestor* gestor = NULL; //lista ligada vazia dos gestores
    int codigoM, codigoC, nifC, codigoG, pinG;
    char tipoM[50], localizacaoM[50], aluguerM[10], nomeC[20], moradaC[30], nomeG[20];
    float bateriaM, autonomiaM, saldoC;

    do {
        Ges = menuGestor();
        switch (Ges)
        {
        case 1: printf("Codigo do Gestor?\n");
                scanf("%d", &codigoG);
                printf("Nome?\n");
                scanf("%s", &nomeG);
                printf("Pin de seguranca?\n");
                scanf("%d", &pinG);
                gestor = inserirGestor(gestor, codigoG, nomeG, pinG);
                break;
        case 2: printf("Codigo do Gestor a remover?\n");
                scanf("%d", &codigoG);
                gestor = removerGestor(gestor, codigoG);
                break;
        case 3: guardarGestor(gestor);
                break;
        case 4: gestor = lerGestor();
                break;
        case 5: printf("Codigo do Gestor a ser alterado?\n");
                scanf("%d", &codigoG);
                printf("Nome do Gestor?\n");
                scanf("%s", &nomeG);
                printf("Pin de seguran�a?\n");
                scanf("%d", &pinG);
                gestor = alterarGestor(gestor, codigoG, nomeG, pinG);
                break;
        case 6: printf("Codigo do Cliente?\n");
                scanf("%d", &codigoC);
                printf("NIF?\n");
                scanf("%d", &nifC);
                printf("Saldo?\n");
                scanf("%f", &saldoC);
                printf("Nome?\n");
                scanf("%s", &nomeC);
                printf("Morada?\n");
                scanf("%s", &moradaC);
                cliente = inserirCliente(cliente, codigoC, nifC, saldoC, nomeC, moradaC);
                break;
        case 7: printf("Codigo do Cliente a remover?\n");
                scanf("%d", &codigoC);
                cliente = removerCliente(cliente, codigoC);
                break;
        case 8: guardarCliente(cliente);
                break;
        case 9: cliente = lerCliente();
                break;
        case 10: printf("Codigo do Cliente a ser alterado?\n");
                 scanf("%d", &codigoC);
                 printf("NIF do Cliente?\n");
                 scanf("%d", &nifC);
                 printf("Saldo do Cliente?\n");
                 scanf("%f", &saldoC);
                 printf("Nome do Cliente?\n");
                 scanf("%s", &nomeC);
                 printf("Morada do Cliente?\n");
                 scanf("%s", &moradaC);
                 cliente = alterarCliente(cliente, codigoC, nifC, saldoC, nomeC, moradaC);
                 break;
        case 11: printf("Codigo do Meio de mobilidade?\n");
                 scanf("%d", &codigoM);
                 printf("Tipo do Meio de mobilidade?\n");
                 scanf("%s", &tipoM);
                 printf("Percentagem da bateria?\n");
                 scanf("%f", &bateriaM);
                 printf("Autonomia?\n");
                 scanf("%f", &autonomiaM);
                 printf("Localizacao com geocodigo?\n");
                 scanf("%s", &localizacaoM);
                 printf("Alugada?\n");
                 scanf("%s", &aluguerM);
                 meio = inserirMeio(meio, codigoM, tipoM, bateriaM, autonomiaM, localizacaoM, aluguerM);
                 break;
        case 12: printf("Codigo do Meio de mobilidade a remover?\n");
                 scanf("%d", &codigoM);
                 meio = removerMeio(meio, codigoM);
                 break;
        case 13: guardarMeio(meio);
                 break;
        case 14: meio = lerMeio();
                 break;
        case 15: listarMeio(meio);
                 break;
        case 16: printf("Codigo do Meio de mobilidade a ser alterado?\n");
                 scanf("%d", &codigoM);
                 printf("Tipo do Meio de mobilidade?\n");
                 scanf("%s", &tipoM);
                 printf("Percentagem da bateria?\n");
                 scanf("%f", &bateriaM);
                 printf("Autonomia?\n");
                 scanf("%f", &autonomiaM);
                 printf("Localizacao com geocodigo?\n");
                 scanf("%s", &localizacaoM);
                 printf("Alugada?\n");
                 scanf("%s", &aluguerM);
                 meio = alterarMeio(meio,codigoM,tipoM,bateriaM,autonomiaM,localizacaoM,aluguerM);
                 break;
        case 17: printf("Codigo do Meio de mobilidade pretendido?\n");
                 scanf("%d", &codigoM);
                 registoAluguerMeio(meio, codigoM);
                 break;
        case 18: printf("Geocodigo para procurar Meios de mobilidade?\n");
                 scanf("%s", &localizacaoM);
                 listarMeioLocalizacao(meio, localizacaoM);
                 break;
        case 19: ordenarMeioDec(meio);
                 break;
        case 20: main();
                 break;
        }
    }while (Ges != 0);
    return(0);
}

//Menu inicial
int main() {
    int ini;
    Meio* meio = NULL; //lista ligada vazia dos meios de mobilidade
    Cliente* cliente = NULL; //lista ligada vazia dos clientes
    Gestor* gestor = NULL; //lista ligada vazia dos gestores
    do {
        ini = menu();
        switch (ini)
        {
        case 1:mCliente();
            break;
        case 2:mGestor();
            break;
        }
    }while (ini != 0);
        return(0);
}