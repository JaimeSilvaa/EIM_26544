/*****************************************************************//**
 * \file   Funcoes.h
 * \brief  Ficheiro funcoes.h onde sao definidas as structs e onde se encontra "a ponte" entre o funcao.c e o main.c
 * 
 * \author Jaime Silva
 * \date   March 2023
 *********************************************************************/
#pragma once
#pragma warning(disable: 4996)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct registoMeio //struct registoMeio
{
    int codigoMeio; //codigo do Meio de mobilidade
    char tipoMeio[50]; //tipo do meio
    float bateriaMeio; //bateria do meio
    float autonomiaMeio; //autonomia do meio
    char localizacaoMeio[50]; //local onde se encontra o meio
    char aluguerMeio[10]; //se o meio se encontra alugado
    struct registoMeio* seguinteM;
}Meio;

typedef struct registoCliente
{
    int codigoCliente; //codigo do cliente
    int NIFCliente; //nif do cliente
    float saldoCliente; //saldo do cliente
    char nomeCliente[20]; //nome do cliente
    char morada[30]; //morada do cliente
    struct registoCliente* seguinteC;
}Cliente;

typedef struct registoGestor
{
    int codigoGestor; //codigo do gestor
    char nomeGestor[20]; //nome do gestor
    int Pin; //pin de seguran�a do gestor
    struct registoGestor* seguinteG;
}Gestor;

//funcoes dos meios de mobilidade
Meio* inserirMeio(Meio* inicioM, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]);
void ordenarMeioDec(Meio* inicioM);
void listarMeio(Meio* atualM);
void listarMeioLocalizacao(Meio* inicioM, char local[]);
int existeMeio(Meio* inicio, int codigo);
Meio* removerMeio(Meio* inicio, int codigo);
Meio* alterarMeio(Meio* inicioM, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]);
int registoAluguerMeio(Meio* inicioM, int codigo);

//funcoes de ficheiros dos meios
int guardarMeio(Meio* inicio);
Meio* lerMeio();

//funcoes dos clientes
Cliente* inserirCliente(Cliente* inicioC, int codigoC, int NIF, float saldo, char nomeC[], char morada[]);
int existeCliente(Cliente* inicioC, int codigoC);
Cliente* removerCliente(Cliente* inicioC, int codigoC);
Cliente* alterarCliente(Cliente* inicioC, int codigoC, int nifC, float saldoC, char nomeC[], char moradaC[]);

//funcoes de ficheiros dos clientes
int guardarCliente(Cliente* inicioC);
Cliente* lerCliente();

//funcoes dos gestores
Gestor* inserirGestor(Gestor* inicioG, int codigoG, char nomeG[], int PIN);
int existeGestor(Gestor* inicioG, int codigoG);
Gestor* removerGestor(Gestor* inicioG, int codigoG);
Gestor* alterarGestor(Gestor* inicioG, int codigoG, char nomeG[], int pinG);

//funcoes de ficheiros dos gestores
int guardarGestor(Gestor* inicioG);
Gestor* lerGestor();
