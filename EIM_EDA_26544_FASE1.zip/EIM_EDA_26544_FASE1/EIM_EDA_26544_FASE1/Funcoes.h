/*****************************************************************//**
 * \file   Funcoes.h
 * \brief  Ficheiro funcoes.h onde sao definidas as structs e onde se encontra "a ponte" entre o funcao.c e o main.c
 * 
 * \author Jaime Silva
 * \date   March 2023
 *********************************************************************/
#pragma once
#pragma warning(disable: 4996)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct registoMeio //struct registoMeio
{
    int codigoMeio; //codigo do Meio de mobilidade
    char tipoMeio[50]; //tipo do meio
    float bateriaMeio; //bateria do meio
    float autonomiaMeio; //autonomia do meio
    char localizacaoMeio[50]; //local onde se encontra o meio
    char aluguerMeio[50]; //se o meio se encontra alugado
    struct registoMeio* seguinte; //endere�o de mem�ria para uma struct registo
}Meio;

typedef struct registoCliente
{
    int codigoCliente; //codigo do cliente
    int NIFCliente; //nif do cliente
    float saldoCliente; //saldo do cliente
    char nomeCliente[50]; //nome do cliente
    char mailCliente[50]; //email do cliente
    struct registoCliente* seguinte; //endere�o de mem�ria para uma struct registo
}Cliente;

typedef struct registoGestor
{
    int codigoGestor; //codigo do gestor
    char nomeGestor[50]; //nome do gestor
    int Pin; //pin de seguran�a do gestor
    struct registoGestor* seguinte; //endere�o de mem�ria para uma struct registo
}Gestor;

//funcoes dos meios de mobilidade
Meio* inserirMeio(Meio* inicio, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]);
Meio* ordenarMeioDec(Meio* inicio);
void listarMeio(Meio* atual);
void apenasListarMeio(char* nomeArquivo);
int existeMeio(Meio* inicio, int codigoM);
Meio* removerMeio(Meio* inicio, int codigoM);
Meio* alterarMeio(Meio* inicio, int codigoM, char tipo[], float bateria, float autonomia, char localizacao[], char aluguer[]);
int registoAluguerMeio(Meio* inicio, int codigo);
void listarMeioAutonomia(Meio* listar);
void listarMeioLocalizacao(Meio* inicio, char localizacao[]);

//funcoes de manipulacao de ficheiros dos meios
int guardarMeio(Meio* inicio);
Meio* lerMeio();

//funcoes dos clientes
Cliente* inserirCliente(Cliente* inicio, int codigoC, int NIF, float saldo, char nomeC[], char mail[]);
int existeCliente(Cliente* inicio, int codigoC);
void listarCliente(Cliente* inicio);
void apenasListarCliente(char* nomeArquivo);
Cliente* removerCliente(Cliente* inicio, int codigoC);
Cliente* alterarCliente(Cliente* inicio, int codigoC, int nifC, float saldoC, char nomeC[], char mail[]);

//funcoes de manipulacao de ficheiros dos clientes
int guardarCliente(Cliente* inicio);
Cliente* lerCliente();

//funcoes dos gestores
Gestor* inserirGestor(Gestor* inicio, int codigoG, char nomeG[], int PIN);
int existeGestor(Gestor* inicio, int codigoG);
//void listarGestor(Gestor* inicio);
void listarGestor(char* nomeArquivo);
Gestor* removerGestor(Gestor* inicio, int codigoG);
Gestor* alterarGestor(Gestor* inicio, int codigoG, char nomeG[], int pinG);

//funcoes de manipulacao de ficheiros dos gestores
int guardarGestor(Gestor* inicio);
//Gestor* lerGestor();


